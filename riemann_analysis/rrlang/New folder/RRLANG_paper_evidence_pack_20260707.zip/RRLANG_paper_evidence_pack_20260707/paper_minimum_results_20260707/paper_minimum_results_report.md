# RRLANG Paper-Minimum Results Report

Generated: 2026-07-07

## Scope

This report contains the minimum additional empirical outputs needed before drafting the RRLANG pilot/methods paper:

1. Mesu register comparison: Mesu UDHR vs Thomas Mesu vs Basho Mesu.
2. Deterministic controls: duplicated Mesu UDHR, punctuation-noise Mesu UDHR, and random bits.

All new runs use RRLANG v0.3, linguistic-profile mode, Markov-2 survivor summaries, and 100 null samples.

## Canonical UDHR calibration

Canonical UDHR Mesu row, punctuation allowed:

| language_guess | trusted_survivor_count | strongest_abs_z | strongest_event | strongest_metric | profile |
| --- | ---: | ---: | --- | --- | --- |
| mesu | 0 | 0.0 |  |  | quiet |

Canonical UDHR Mesu row, punctuation excluded:

| language_guess | trusted_survivor_count | strongest_abs_z | strongest_event | strongest_metric | profile |
| --- | ---: | ---: | --- | --- | --- |
| mesu | 0 | 0.0 |  |  | quiet |

## Mesu register input summary

_No trusted survivors after filtering._

## Mesu register top trusted survivors

_No trusted survivors after filtering._

## Controls input summary

| input | trusted_survivor_count | strongest_abs_z | strongest_event | strongest_metric |
| --- | --- | --- | --- | --- |
|  | 16 | 94.141613377514 | word_boundary | run_entropy |

## Controls top trusted survivors

| language_guess | encoding | event | metric | z | p_emp | input |
| --- | --- | --- | --- | --- | --- | --- |
| unknown | word_boundary | word_boundary | run_entropy | -94.141613377514 | 0.009900990099 |  |
| unknown | word_boundary | word_boundary | gap_entropy | -93.641445325503 | 0.009900990099 |  |
| unknown | word_boundary | word_boundary | prime_gap_affinity | -7.1217366277 | 0.009900990099 |  |
| mesu | grapheme_class | punctuation | run_entropy | -5.717142570019 | 0.009900990099 |  |
| mesu | grapheme_class | punctuation | gap_entropy | -5.644008350764 | 0.009900990099 |  |
| mesu | grapheme | punctuation | run_entropy | -5.61504761589 | 0.009900990099 |  |
| mesu | grapheme | punctuation | gap_entropy | -5.537641391811 | 0.009900990099 |  |
| mesu | frequency_class | high_frequency | run_entropy | -5.365652554623 | 0.009900990099 |  |
| unknown | word_boundary | word_boundary | prime_index_occupancy_bias | -5.049135673871 | 0.009900990099 |  |
| mesu | frequency_class | mid_frequency | run_entropy | -4.607846069294 | 0.009900990099 |  |
| mesu | grapheme_class | vowel | prime_gap_affinity | -4.453373385272 | 0.009900990099 |  |
| mesu | grapheme | vowel | prime_gap_affinity | -4.332295987792 | 0.009900990099 |  |
| mesu | frequency_class | mid_frequency | gap_entropy | -4.067543041046 | 0.009900990099 |  |
| mesu | word_boundary | word_boundary | gap_entropy | -3.817918853249 | 0.009900990099 |  |
| mesu | grapheme | punctuation | prime_gap_affinity | 3.460460066451 | 0.009900990099 |  |
| mesu | word_boundary | word_boundary | prime_gap_affinity | 3.35995778752 | 0.009900990099 |  |

## Generated files

- mesu_register_trusted_survivors.csv
- mesu_register_input_summary.csv
- controls_trusted_survivors.csv
- controls_input_summary.csv
- canonical_udhr_final_comparison_table.csv, if available
- canonical_udhr_no_punctuation_final_comparison_table.csv, if available

## Paper-readiness interpretation rule

Use the canonical UDHR result as calibration. Use Mesu register as the only Mesu-positive/negative register test. Use controls only as artefact sanity checks. Do not add more broad corpus results before drafting paper v0.1.
