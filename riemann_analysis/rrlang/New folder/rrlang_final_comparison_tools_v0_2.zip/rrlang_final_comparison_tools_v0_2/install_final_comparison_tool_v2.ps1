# install_final_comparison_tool_v2.ps1
# Installs build_final_comparison_table.py into the RRLANG repo scripts folder.
# Run this from the extracted patch folder, not by double-clicking.

$ErrorActionPreference = "Stop"

$DefaultRepo = "D:\code\5hr-conlang\riemann_analysis\rrlang"
if (Test-Path $DefaultRepo) {
    $Repo = $DefaultRepo
} else {
    $Repo = Read-Host "Enter full path to your rrlang repo"
}

$ScriptDir = Join-Path $Repo "scripts"
New-Item -Force -ItemType Directory $ScriptDir | Out-Null

$Source = Join-Path $PSScriptRoot "build_final_comparison_table.py"
$Dest = Join-Path $ScriptDir "build_final_comparison_table.py"

Copy-Item -Force $Source $Dest

Write-Host "Installed:" -ForegroundColor Green
Write-Host "  $Dest"
Write-Host ""
Write-Host "Run this from repo root:" -ForegroundColor Cyan
Write-Host "  cd $Repo"
Write-Host "  py -3 .\scripts\build_final_comparison_table.py --summary .\outputs\summary_canonical_udhr_v0_3_nulls100_labeled --out .\outputs\final_tables\canonical_udhr_v0_3"
