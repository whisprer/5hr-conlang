# RRLANG Final Comparison Tools v0.2

This package installs `build_final_comparison_table.py`.

## Install without opening VS Code

Extract this zip. In PowerShell, `cd` into the extracted folder and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\install_final_comparison_tool_v2.ps1
```

Do not double-click the `.ps1` file; on some Windows setups that opens VS Code.

## Manual install

Copy:

```text
build_final_comparison_table.py
```

into:

```text
D:\code\5hr-conlang\riemann_analysis\rrlang\scripts\build_final_comparison_table.py
```

## Run

From the RRLANG repo root:

```powershell
cd D:\code\5hr-conlang\riemann_analysis\rrlang

py -3 .\scripts\build_final_comparison_table.py `
  --summary .\outputs\summary_canonical_udhr_v0_3_nulls100_labeled `
  --out .\outputs\final_tables\canonical_udhr_v0_3
```

## Stricter no-punctuation version

```powershell
py -3 .\scripts\build_final_comparison_table.py `
  --summary .\outputs\summary_canonical_udhr_v0_3_nulls100_labeled `
  --out .\outputs\final_tables\canonical_udhr_v0_3_no_punctuation `
  --exclude-punctuation
```
