# rrlang

`rrlang` is the MVP Rust research instrument for **Riemann-Resonant Linguistics**.

It is intentionally built as a measurement engine, not an oracle. It reports positional metrics, null-model comparisons, and evidence-tiered warnings for language-system analysis.

## Current MVP scope

Supported encoding layers:

- `utf8_bits` — raw UTF-8 diagnostic bitstream, not primary linguistic evidence.
- `grapheme` — deterministic Unicode-scalar stream used as an MVP grapheme approximation.
- `grapheme_class` — broad classes such as vowel, consonant, digit, whitespace, punctuation, other.
- `word_boundary` — whitespace-derived boundary bitmap.
- `frequency_class` — sample-local token frequency classes: hapax, mid-frequency, high-frequency.

Supported metric families:

- Event density
- Shannon symbol entropy
- Gap entropy
- Run entropy
- Prime-indexed occupancy bias
- Prime-gap affinity
- Modular residue peaks for mod 2, 3, 5, and 7
- Zeta-like spectral coherence
- Critical-line symmetry score
- Basic anti-pattern and artefact alerts

Supported null model in this MVP:

- Shuffle preserving event count / binary density, used as the baseline for event-map null comparisons.

This MVP deliberately does **not** yet include phonemic, morphemic, POS, or diachronic layers. Those are later extensions.

## Build

From the repository root:

```bash
cargo build --release
```

The binary will be at:

```bash
target/release/rrlang
```

On Windows PowerShell:

```powershell
cargo build --release
.\target\release\rrlang.exe help
```

## Run a quick inspection

```bash
cargo run -p rrlang -- inspect --input testdata/tiny/english.txt
```

## Run an MVP analysis

```bash
cargo run -p rrlang -- analyse \
  --input testdata/tiny/english.txt \
  --language English \
  --nulls 100 \
  --out outputs/english_report.json \
  --text-out outputs/english_report.txt
```

PowerShell version:

```powershell
cargo run -p rrlang -- analyse `
  --input testdata/tiny/english.txt `
  --language English `
  --nulls 100 `
  --out outputs/english_report.json `
  --text-out outputs/english_report.txt
```

## Run from config

```bash
cargo run -p rrlang -- analyse --config examples/config_basic.toml
```

## Interpretation discipline

`rrlang` reports:

- what was measured,
- which encoding layer it came from,
- how it compared against shuffle nulls,
- what alerts were triggered,
- and what interpretation level is allowed.

It does **not** report:

- proof of artificiality,
- proof of AI authorship,
- proof of alien origin,
- proof of hidden prime causality,
- or any claim about the Riemann Hypothesis.

Raw UTF-8 findings are diagnostic only unless they survive meaningful linguistic encodings.

## Known MVP limitations

- The `grapheme` layer currently uses Unicode scalar values, not full Unicode extended grapheme clusters.
- The word-boundary layer is whitespace-derived.
- The frequency-class layer calculates frequencies only inside the supplied sample.
- Null models are intentionally minimal in this first version.
- Results should be treated as exploratory.

These limitations are design-contained and reported in tool notes/alerts rather than hidden.
