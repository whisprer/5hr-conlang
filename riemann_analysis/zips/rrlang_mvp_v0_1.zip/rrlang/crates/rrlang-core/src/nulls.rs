#[derive(Debug, Clone)]
pub struct XorShift64 {
    state: u64,
}

impl XorShift64 {
    pub fn new(seed: u64) -> Self {
        let state = if seed == 0 { 0x9E37_79B9_7F4A_7C15 } else { seed };
        Self { state }
    }

    pub fn next_u64(&mut self) -> u64 {
        let mut x = self.state;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.state = x;
        x
    }

    pub fn gen_range(&mut self, upper_exclusive: usize) -> usize {
        if upper_exclusive <= 1 {
            return 0;
        }
        (self.next_u64() as usize) % upper_exclusive
    }
}

pub fn shuffle_bool_preserving_count(values: &[bool], rng: &mut XorShift64) -> Vec<bool> {
    let mut shuffled = values.to_vec();
    if shuffled.len() < 2 {
        return shuffled;
    }
    for i in (1..shuffled.len()).rev() {
        let j = rng.gen_range(i + 1);
        shuffled.swap(i, j);
    }
    shuffled
}
