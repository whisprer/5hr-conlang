param(
  [string]$RrLangRepo = "..\rrlang_mvp_v0_2",
  [string]$PackRoot = ".",
  [int]$Nulls = 100
)

$ErrorActionPreference = "Stop"
$pack = Resolve-Path $PackRoot
$rr = Resolve-Path $RrLangRepo
$out = Join-Path $pack "outputs\udhr_batch"
New-Item -Force -ItemType Directory $out | Out-Null

$files = Get-ChildItem -Recurse -File (Join-Path $pack "datasets\parallel\udhr") -Filter "*.txt" |
  Where-Object { $_.FullName -notmatch "source_raw" }

foreach ($f in $files) {
  $name = [IO.Path]::GetFileNameWithoutExtension($f.Name)
  $safe = ($f.Directory.Name + "_" + $name) -replace '[^A-Za-z0-9_\-]', '_'
  $lang = $f.Directory.Name
  Write-Host "Analysing $safe"
  Push-Location $rr
  cargo run -p rrlang -- analyse `
    --input $f.FullName `
    --language $lang `
    --hyphen-policy morpheme_boundary `
    --nulls $Nulls `
    --out (Join-Path $out "$safe.json") `
    --text-out (Join-Path $out "$safe.txt")
  Pop-Location
}
