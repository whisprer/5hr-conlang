param(
  [string]$PackRoot = ".",
  [string]$Only = "",
  [string]$Prefer = "ohchr,efele,bulk"
)
$ErrorActionPreference = "Stop"
py -3 scripts\fetch_udhr_pack.py --root $PackRoot --only $Only --prefer $Prefer
py -3 scripts\generate_controls.py
