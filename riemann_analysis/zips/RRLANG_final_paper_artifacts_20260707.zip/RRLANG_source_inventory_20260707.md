# RRLANG Paper Source Inventory

Generated: 2026-07-07

## Project inputs supplied by user

- `riemann_paper.txt` — original long-form Riemann-Resonant Linguistics draft.
- `RRLANG_HANDOVER_2026-07-06(1).md` — project handover describing v0.3 status, canonical UDHR results, and recommended paper framing.
- `RRLANG_paper_evidence_pack_20260707.zip` — evidence pack containing result tables, paper-minimum report, Git metadata, CLI help, Cargo workspace manifest, and analysis scripts.

## Evidence pack contents

```text
./Cargo.toml
./build_final_comparison_table.py
./canonical_udhr_v0_3/final_comparison_table.csv
./canonical_udhr_v0_3/final_comparison_table.md
./canonical_udhr_v0_3/metric_family_summary.csv
./canonical_udhr_v0_3/strongest_by_language.csv
./canonical_udhr_v0_3/trusted_markov2_survivors.csv
./canonical_udhr_v0_3_no_punctuation/final_comparison_table.csv
./canonical_udhr_v0_3_no_punctuation/final_comparison_table.md
./canonical_udhr_v0_3_no_punctuation/metric_family_summary.csv
./canonical_udhr_v0_3_no_punctuation/strongest_by_language.csv
./canonical_udhr_v0_3_no_punctuation/trusted_markov2_survivors.csv
./git_commit.txt
./git_log_recent.txt
./git_status_short.txt
./paper_minimum_results_20260707/canonical_udhr_final_comparison_table.csv
./paper_minimum_results_20260707/canonical_udhr_no_punctuation_final_comparison_table.csv
./paper_minimum_results_20260707/controls_input_summary.csv
./paper_minimum_results_20260707/controls_trusted_survivors.csv
./paper_minimum_results_20260707/mesu_register_input_summary.csv
./paper_minimum_results_20260707/mesu_register_trusted_survivors.csv
./paper_minimum_results_20260707/paper_minimum_results_report.md
./repair_canonical_udhr_labels.ps1
./rrlang_batch_help.txt
./rrlang_help.txt
./run_paper_minimum_results.ps1
./summarise_rrlang_reports_v3.py
```

## Web-searched literature and reference anchors

- Shannon, C. E. (1948). *A Mathematical Theory of Communication*. https://people.math.harvard.edu/~ctm/home/text/others/shannon/entropy/entropy.pdf
- Zipf, G. K. (1949). *Human Behavior and the Principle of Least Effort*. https://web.stanford.edu/class/psych227/Zipf_Words.pdf
- Mandelbrot, B. (1953). *An Informational Theory of the Statistical Structure of Language*. https://pdodds.w3.uvm.edu/files/papers/others/1953/mandelbrot1953a.pdf
- Heaps' law overview via Manning, Raghavan, and Schuetze, *Introduction to Information Retrieval*. https://nlp.stanford.edu/IR-book/html/htmledition/heaps-law-estimating-the-number-of-terms-1.html
- Markov-chain textual analysis historical overview, *American Scientist*. https://www.americanscientist.org/article/first-links-in-the-markov-chain
- Altmann, E. G. and Gerlach, M. (2015). *Statistical laws in linguistics*. https://arxiv.org/abs/1502.03296
- Montemurro, M. A. and Zanette, D. H. (2011). *Universal entropy of word ordering across linguistic families*. https://pmc.ncbi.nlm.nih.gov/articles/PMC3094390/
- Burrows, J. (2002). *Delta: a Measure of Stylistic Difference and a Guide to Likely Authorship*. https://academic.oup.com/dsh/article-abstract/17/3/267/929277
- Stamatatos, E. (2009). *A survey of modern authorship attribution methods*. https://onlinelibrary.wiley.com/doi/abs/10.1002/asi.21001
- Benjamini, Y. and Hochberg, Y. (1995). *Controlling the False Discovery Rate*. https://rss.onlinelibrary.wiley.com/doi/10.1111/j.2517-6161.1995.tb02031.x
- Unicode Standard Annex #15: Unicode Normalization Forms. https://www.unicode.org/reports/tr15/
- Unicode Standard Annex #29: Unicode Text Segmentation. https://www.unicode.org/reports/tr29/
- United Nations UDHR page. https://www.un.org/en/about-us/universal-declaration-of-human-rights
- Aalto University UDHR corpus. https://research.ics.aalto.fi/cog/data/udhr/
- Universal Dependencies project. https://universaldependencies.org/

## Caveat

The supplied evidence pack did not contain the Rust `src/` tree. The final paper therefore includes the analysis scripts, table scripts, CLI help, Git metadata, and Cargo workspace manifest, but not a full Rust source-code appendix.
